Practical 3
